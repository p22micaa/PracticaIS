#include "agenda.h"
#include <string>
#include <fstream>
#include <list>
#include <iostream>
#include <cstdlib>


	vector<Contacto> Agenda::MostrarContactos(){
		vector<Contacto> contactos;
		list <Contacto> :: iterator i = _contactos.begin();
		for(i=_contactos.begin(); i!=_contactos.end(); i++)
			{
				contactos.push_back(*i);
			}
		if(contactos.empty()){
			cout<<"Error: no hay contactos en la agenda"<<endl;
		}
		return contactos;
	}

vector<Contacto> Agenda::BuscarContacto(){
	cout<<"Introduzca un apellido para buscar:"<<endl;
	vector<Contacto> contactosBuscados;
	string apellido;
	cin>>apellido;
	list <Contacto> :: iterator i = _contactos.begin();
	for(i=_contactos.begin(); i!=_contactos.end(); i++)
		{
			if(i->getApellido1()==apellido || i->getApellido2()==apellido)
			{
				contactosBuscados.push_back(*i);
			}
		}
	if(contactosBuscados.empty()){
		cout<<"Error: apellido no encontrado"<<endl;
	}
	return contactosBuscados;
}

vector<Contacto> Agenda::BuscarFavorito(){
	vector<Contacto> contactosBuscados;
	list <Contacto> :: iterator i = _contactos.begin();
	for(i=_contactos.begin(); i!=_contactos.end(); i++)
		{
			if(i->isFavoritos())
			{
				contactosBuscados.push_back(*i);
			}
		}
	if(contactosBuscados.empty()){
		cout<<"Error: no hay contactos favoritos"<<endl;
	}
	return contactosBuscados;
}

vector<Contacto> Agenda::BuscarMasUsados(){
	vector<Contacto> contactosBuscados;
	list <Contacto> :: iterator i = _contactos.begin();
	for(i=_contactos.begin(); i!=_contactos.end(); i++)
		{
			if(i->getMasUsados()>=5)
			{
				contactosBuscados.push_back(*i);
			}
		}
	if(contactosBuscados.empty()){
		cout<<"Error: no hay contactos frecuentes"<<endl;
	}
	return contactosBuscados;
}


void Agenda::InsertarUsuario(Contacto cont){
	int enc=0;
	if(!_contactos.empty()){
		list <Contacto> :: iterator i = _contactos.begin();
		for(i=_contactos.begin(); i!=_contactos.end(); i++)
			{
				if(i->getDni()==cont.getDni() && enc==0)
				{
					cout<<"Error: el DNI ya esta inlcuido"<<endl;
					enc=1;
					break;
				}
			}
	}
	else {
		_contactos.push_back(cont);
	}

	if(enc==0){
	list <Contacto> :: iterator i = _contactos.begin();
	for(i=_contactos.begin(); i!=_contactos.end(); i++)
		{
			if(i->getApellido1()>cont.getApellido1())
			{
				_contactos.insert(i, 1, cont);
				cout<<"Contacto insertado"<<endl;
				break;
			}
		}
	}

}


void Agenda::eliminarContacto(string DNI)
{
	int control=0;
	list <Contacto> :: iterator i;
	if(!_contactos.empty())
	{
		for(i=_contactos.begin(); i!=_contactos.end(); i++)
		{
			if(i->getDni()==DNI)
			{
				_contactos.erase(i);
				control=1;
				break;
			}
		}
	}
	if(control==0)
		{
			cout<<"Error: DNI no encontrado"<<endl;
		}

}

void Agenda::modificarContacto(string DNI){
	int enc=0;
	list <Contacto> :: iterator i;
	if(!_contactos.empty()) {
		for(i=_contactos.begin(); i!=_contactos.end(); i++)
		{
			if(i->getDni()==DNI && enc==0){
				cout<<*i<<endl;
				*i=crearContacto(DNI);
				enc=1;
				break;
			}
		}
		if(enc==0){
			cout<<"No existe ningun contacto con el dni proporcionado"<<endl;
		}
	}
	else {
		cout<<"No existe ningun contacto en la agenda"<<endl;
	}
}


void Agenda::guardarEnFichero(int fichero){
	ofstream fs1("agenda.txt");
	fs1.close();
	ofstream fs2("agendaCopiaSeguridad.txt");
	fs2.close();
	list<Contacto>::iterator i;
	if(fichero==0){
		system("rm agenda.txt");
		ofstream fs("agenda.txt");
		for(i=_contactos.begin();i!=_contactos.end();i++){
			fs<<i->getDni()<<",";
			fs<<i->getNombre()<<",";
			fs<<i->getApellido1()<<",";
			fs<<i->getApellido2()<<",";
			fs<<i->getTelefono()<<",";
			fs<<i->getEmail()<<",";
			fs<<i->getAnotaciones()<<",";
			fs<<i->isFavoritos()<<",";
			fs<<i->getMasUsados()<<",";
			fs<<i->getRedes().login<<",";
			fs<<i->getRedes().tipo_red<<",";
			fs<<i->getDireccionPostal().calle<<",";
			fs<<i->getDireccionPostal().cp<<",";
			fs<<i->getDireccionPostal().numero<<endl;
		}
		fs.close();
	}
	else{
		system("rm agendaCopiaSeguridad.txt");
		ofstream fs("agendaCopiaSeguridad.txt");
		for(i=_contactos.begin();i!=_contactos.end();i++){
				fs<<i->getDni()<<",";
				fs<<i->getNombre()<<",";
				fs<<i->getApellido1()<<",";
				fs<<i->getApellido2()<<",";
				fs<<i->getTelefono()<<",";
				fs<<i->getEmail()<<",";
				fs<<i->getAnotaciones()<<",";
				fs<<i->isFavoritos()<<",";
				fs<<i->getMasUsados()<<",";
				fs<<i->getRedes().login<<",";
				fs<<i->getRedes().tipo_red<<",";
				fs<<i->getDireccionPostal().calle<<",";
				fs<<i->getDireccionPostal().cp<<",";
				fs<<i->getDireccionPostal().numero<<endl;
		}
		fs.close();
	}
}

void Agenda :: cargarDesdeFichero(int fichero){
	string nif,nomb,a1,a2,telf,mail,anotacion,log,tipoR,cle,cP;
	bool fav;
	int ms,num;
	char dni[20],nombre[20],apellido1[20],apellido2[20],telefono[20],email[40],anotaciones[120],favoritos[20],masUsados[20],redesLogin[20],redesTipoRed[20],direccionCalle[64],direccionCP[20],direccionNumero[20];
	_contactos.clear();
	if(fichero==0){
		ifstream fs("agenda.txt");
		while(fs.getline(dni,256,','))
		{
			fs.getline(nombre,256,',');
			fs.getline(apellido1,256,',');
			fs.getline(apellido2,256,',');
			fs.getline(telefono,256,',');
			fs.getline(email,256,',');
			fs.getline(anotaciones,256,',');
			fs.getline(favoritos,256,',');
			fs.getline(masUsados,256,',');
			fs.getline(redesLogin,256,',');
			fs.getline(redesTipoRed,256,',');
			fs.getline(direccionCalle,256,',');
			fs.getline(direccionCP,256,',');
			fs.getline(direccionNumero,256,'\n');
			nif=dni;
			nomb=nombre;
			a1=apellido1;
			a2=apellido2;
			telf=telefono;
			mail=email;
			anotacion=anotaciones;
			log=redesLogin;
			tipoR=redesTipoRed;
			cle=direccionCalle;
			cP=direccionCP;
			ms=atoi(masUsados);
			num=atoi(direccionNumero);
			fav=atoi(favoritos);
			InsertarUsuario(Contacto(nif,nomb,a1,a2,telf,anotacion, mail, tipoR, log, cle, cP, num, fav, ms));
		}
	}
	else{
		ifstream fs("agendaCopiaSeguridad.txt");
		while(fs.getline(dni,256,','))
		{
			fs.getline(nombre,256,',');
			fs.getline(apellido1,256,',');
			fs.getline(apellido2,256,',');
			fs.getline(telefono,256,',');
			fs.getline(email,256,',');
			fs.getline(anotaciones,256,',');
			fs.getline(favoritos,256,',');
			fs.getline(masUsados,256,',');
			fs.getline(redesLogin,256,',');
			fs.getline(redesTipoRed,256,',');
			fs.getline(direccionCalle,256,',');
			fs.getline(direccionCP,256,',');
			fs.getline(direccionNumero,256,'\n');
			nif=dni;
			nomb=nombre;
			a1=apellido1;
			a2=apellido2;
			telf=telefono;
			mail=email;
			anotacion=anotaciones;
			log=redesLogin;
			tipoR=redesTipoRed;
			cle=direccionCalle;
			cP=direccionCP;
			ms=atoi(masUsados);
			num=atoi(direccionNumero);
			fav=atoi(favoritos);
			InsertarUsuario(Contacto(nif,nomb,a1,a2,telf,anotacion, mail, tipoR, log, cle, cP, num, fav, ms));
		}
	}
}

Contacto Agenda::crearContacto(string dni){
	int an;
	string DNI, nombre, apellido1, apellido2, telefono, anotaciones, email;
	char nom[20], nota[120];
	if (dni==" "){
		cout<<"Introduzca DNI"<<endl;
		cin>>DNI;
	}
	else {
		DNI=dni;
	}

	cout<<"Introduzca el nombre"<<endl;
	cin.getline(nom, 20);
	nombre(nom);

	cout<<"Introduzca el primer apellido"<<endl;
	cin>>apellido1;

	cout<<"Introduzca el segundo apellido"<<endl;
	cin>>apellido2;

	cout<<"Introduzca el telefono"<<endl;
	cin>>telefono;

	cout<<"�Desea introducir anotaciones?: 0=NO 1=SI"<<endl;
	cin>>an;
	if(an==0){anotaciones=" ";}
	else{
		cout<<"Introduzca anotaciones"<<endl;
		cin>>anotaciones;
	}

	cout<<"�Desea introducir un email?: 0=NO 1=SI"<<endl;
	cin>>an;
	if(an==0){email=" ";}
	else{
		cout<<"Introduzca el email"<<endl;
		cin>>email;
	}

	return Contacto(DNI, nombre, apellido1, apellido2, telefono, anotaciones, email);

}

