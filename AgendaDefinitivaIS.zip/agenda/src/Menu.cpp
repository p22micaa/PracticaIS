#include"agenda.h"

void visualizarVectorContactos(vector<Contacto> v, int control);

int main()
{
	Agenda a;
	a.cargarDesdeFichero(0);
	string dni;
	int m1=1;
	while(m1!=0){
	cout<<"Elija la opcion:"<<endl;
	cout<<"0: Cerrar"<<endl;
	cout<<"1: Buscar contacto por apellido"<<endl;
	cout<<"2: Listar contactos favoritos"<<endl;
	cout<<"3: Listar contactos frecuentes"<<endl;
	cout<<"4: Insertar contacto"<<endl;
	cout<<"5: Eliminar contacto"<<endl;
	cout<<"6: Modificar contacto"<<endl;
	cout<<"7: Realizar copia de seguridad"<<endl;
	cout<<"8: Restaurar desde copia de seguridad"<<endl;
	cout<<"9: Mostrar todos los contactos"<<endl;

	cin>>m1;
		switch(m1){
		case 1:
			visualizarVectorContactos(a.BuscarContacto(), 0);
			break;
		case 2:
			visualizarVectorContactos(a.BuscarFavorito(), 1);
			break;
		case 3:
			visualizarVectorContactos(a.BuscarMasUsados(), 1);
			break;
		case 4:
			a.InsertarUsuario(a.crearContacto(" "));
			break;
		case 5:
			cout<<"Introduzca DNI del usuario que desea eliminar"<<endl;
			cin>>dni;
			a.eliminarContacto(dni);
			break;
		case 6:
			cout<<"Introduzca DNI del usuario que desea modificar"<<endl;
			cin>>dni;
			a.modificarContacto(dni);
			break;
		case 7:
			a.guardarEnFichero(1);
			break;
		case 8:
			a.cargarDesdeFichero(1);
			break;
		case 9:
			visualizarVectorContactos(a.MostrarContactos(), 1);
			break;
		};
	}
	a.guardarEnFichero(0);
	return 0;
}

void visualizarVectorContactos(vector<Contacto> v, int control){
	int i, seleccion;
	int tv=v.size();
	for(i=0; i<tv; i++){
		cout<<v[i]<<endl;
	}
	if(control==1){
		cout<<"Seleccione contacto escribiendo su posicion (desde 1 a "<<tv<<")"<<endl;
		cin>>seleccion;
		v[seleccion-1].incMasUsados();
		cout<<v[seleccion-1]<<endl;
	}
}



