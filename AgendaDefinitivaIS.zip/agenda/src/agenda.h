#ifndef AGENDA_H
#define AGENDA_H
#include <list>
#include "contacto.h"
#include <vector>
using namespace std;
#include <fstream>


class Agenda {

public:
	vector<Contacto> MostrarContactos();
	vector<Contacto> BuscarContacto();
	vector<Contacto> BuscarFavorito();
	vector<Contacto> BuscarMasUsados();
	void InsertarUsuario(Contacto cont);
	void eliminarContacto(string DNI);
	void modificarContacto(string DNI);
	void guardarEnFichero(int fichero);
	void cargarDesdeFichero(int fichero);
	Contacto crearContacto(string DNI);

private:
	list<Contacto> _contactos;
};
#endif
