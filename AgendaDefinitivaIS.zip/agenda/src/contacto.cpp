
/*
 * Contacto.cpp
 *
 *  Created on: 4/12/2014
 *      Author: yo
 */

#include "contacto.h"

const std::string& Contacto::getAnotaciones() const {
	return _anotaciones;
}

void Contacto::setAnotaciones(const std::string& anotaciones) {
	_anotaciones = anotaciones;
}

const std::string& Contacto::getApellido1() const {
	return _apellido1;
}

void Contacto::setApellido1(const std::string& apellido1) {
	_apellido1 = apellido1;
}

const std::string& Contacto::getApellido2() const {
	return _apellido2;
}

void Contacto::setApellido2(const std::string& apellido2) {
	_apellido2 = apellido2;
}


const std::string& Contacto::getDni() const {
	return _DNI;
}

void Contacto::setDni(const std::string& dni) {
	_DNI = dni;
}

bool Contacto::isFavoritos() const {
	return _favoritos;
}

void Contacto::setFavoritos(bool favoritos) {
	_favoritos = favoritos;
}

int Contacto::getMasUsados() const {
	return _mas_usados;
}

void Contacto::setMasUsados(int masUsados) {
	_mas_usados = masUsados;
}

void Contacto::incMasUsados() {
	_mas_usados++;
}

const std::string& Contacto::getNombre() const {
	return _nombre;
}

void Contacto::setNombre(const std::string& nombre) {
	_nombre = nombre;
}

const redsocial& Contacto::getRedes() const {
	return _redes;
}

void Contacto::setRedes(string tipoRed, string nombreUsuario) {
	_redes.login=nombreUsuario;
	_redes.tipo_red=tipoRed;
}

const std::string& Contacto::getTelefono() const {
	return _telefono;
}

void Contacto::setTelefono(const std::string& telefono) {
	_telefono = telefono;
}

const direccion& Contacto::getDireccionPostal() const {
	return _direccion;
}

const std::string& Contacto::getEmail() const{
	return _email;
}
void Contacto::setEmail(const std::string& email){
	_email=email;
}

void Contacto::setDireccionPostal(string calle, string cp, int num) {
_direccion.calle=calle;
_direccion.cp=cp;
}

ostream& operator<<(ostream& os,const Contacto &c)
{
os<<c.getDni()<<" "<<c.getNombre()<<" "<<c.getApellido1()<<" "<<c.getApellido2()<<" "<<c.getTelefono()<<" "<<c.getEmail()<<" "<<c.getAnotaciones()<<" "<<c.isFavoritos()<<" "<<c.getMasUsados()<<" "<<c.getRedes().login<<" "<<c.getRedes().tipo_red<<" "<<c.getDireccionPostal().calle<<" "<<c.getDireccionPostal().cp<<" "<<c.getDireccionPostal().numero<<endl;
return os;
}

/*friend istream& operator>>(istream& is,Contacto &c){
	return is;
}*/

Contacto& Contacto :: operator=(const Contacto &c)
{
	setDni(c.getDni());
	setNombre(c.getNombre());
	setApellido1(c.getApellido1());
	setApellido2(c.getApellido2());
	setTelefono(c.getTelefono());
	setAnotaciones(c.getAnotaciones());
	setEmail(c.getEmail());
	_direccion=c.getDireccionPostal();
	_redes=c.getRedes();
	setFavoritos(c.isFavoritos());
	setMasUsados(c.getMasUsados());
	return *this;
}


Contacto::Contacto(string _DNI,string _nombre,string _apellido1,string _apellido2,string _telefono,string _anotaciones, string _email){
	setDni(_DNI);
	setNombre(_nombre);
	setApellido1(_apellido1);
	setApellido2(_apellido2);
	setTelefono(_telefono);
	setAnotaciones(_anotaciones);
	setEmail(_email);

	cout<<"Introduzca la direccion, codigo postal y numero:"<<endl;
	char dir[64];
	cin.getline(dir, 20);
	_direccion.calle(dir);
	cin>>_direccion.cp>>_direccion.numero;

	cout<<"Introduzca el nombre de la red social y el nombre del usuario:"<<endl;
	cin>>_redes.tipo_red>>_redes.login;

	setFavoritos(false);
	setMasUsados(0);
}

Contacto::Contacto(string _DNI,string _nombre,string _apellido1,string _apellido2,string _telefono,string _anotaciones, string _email, string tipoRed, string nombreRed, string calle, string cp, int num, bool fav, int masUsados){
	setDni(_DNI);
	setNombre(_nombre);
	setApellido1(_apellido1);
	setApellido2(_apellido2);
	setTelefono(_telefono);
	setAnotaciones(_anotaciones);
	setEmail(_email);
	setDireccionPostal(calle, cp, num);
	setRedes(tipoRed, nombreRed);
	setFavoritos(fav);
	setMasUsados(masUsados);
}




