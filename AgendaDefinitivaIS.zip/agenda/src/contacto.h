#ifndef CONTACTO_H_
#define CONTACTO_H_

#include <string>
#include <iostream>
#include <list>

using namespace std;

typedef struct {
	std::string login;
	std::string tipo_red;
}redsocial;

typedef struct {
	std::string calle;
	std::string cp;
	int numero;
}direccion;

class Contacto {
public:
	const std::string& getAnotaciones() const;
	void setAnotaciones(const std::string& anotaciones);
	const std::string& getApellido1() const;
	void setApellido1(const std::string& apellido1);
	const std::string& getApellido2() const;
	void setApellido2(const std::string& apellido2);
	const std::string& getDni() const;
	void setDni(const std::string& dni);
	bool isFavoritos() const;
	void setFavoritos(bool favoritos);
	int getMasUsados() const;
	void setMasUsados(int masUsados);
	void incMasUsados();
	const std::string& getNombre() const;
	void setNombre(const std::string& nombre);
	const redsocial& getRedes() const;
	void setRedes(string tipoRed, string nombreUsuario);
	const std::string& getTelefono() const;
	void setTelefono(const std::string& telefono);
	const direccion& getDireccionPostal() const;
	void setDireccionPostal(string calle, string cp, int num);
	const std::string& getEmail() const;
	void setEmail(const std::string& email);
	Contacto(string _DNI,string _nombre,string _apellido1,string _apellido2,string _telefono,string _anotaciones, string _email);
	Contacto(string _DNI,string _nombre,string _apellido1,string _apellido2,string _telefono,string _anotaciones, string _email, string tipoRed, string nombreRed, string calle, string cp, int num, bool fav, int masUsados);
	friend ostream& operator<<(ostream& os,const Contacto &c);
	//friend istream& operator>>(istream& is,Contacto &c);
	Contacto& operator=(const Contacto &c);

private:
	std::string _DNI;
	std::string _nombre;
	std::string _apellido1;
	std::string _apellido2;
	std::string _telefono;
	string _email;
	direccion _direccion;
	std::string _anotaciones;
	bool _favoritos;
	int _mas_usados;
	redsocial _redes;

};



#endif /* CONTACTO_H_ */
